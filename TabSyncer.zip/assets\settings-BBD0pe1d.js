import{k as a}from"./index-Bo8VaY9y.js";function i(){return a.get("/tab/api/v1/settings").then(t=>t.data)}function s(t){return a.put("/tab/api/v1/settings",t).then(e=>e.data)}export{i as g,s as u};
